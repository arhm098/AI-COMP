import streamlit as st

st.set_page_config(layout="wide", page_title="Tech Fest Contest NN")

st.markdown(
    """
    <style>
    .big-font {
        font-size: 36px;
        text-align: center;
        font-weight: bold
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown('<p class="big-font">WELCOME TO OUR DEMO</p>', unsafe_allow_html=True)

