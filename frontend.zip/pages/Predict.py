import streamlit as st
import sys
sys.path.append('..') 

    # Add other methods related to ImageProcessing

################################################################################################################################################################

st.set_page_config(layout="wide", page_title="Face Verification")
st.markdown("<h1 style='text-align: left; color: white; font-size: 50px;'>Face Verification</h1>", unsafe_allow_html=True)

#SIDE BAR CUSTOMIZATION CODE
st.write("# Control Panel :gear:")

sub_product = st.text_input("Enter your sub product name:", max_chars=50, key=None, type="default", placeholder=None, label_visibility="visible")
issue = st.text_input("Enter your issue:", max_chars=50, key=None, type="default", placeholder=None, label_visibility="visible")
sub_issue = st.text_input("Enter your sub-issue:", max_chars=50, key=None, type="default", placeholder=None, label_visibility="visible")

customer_narrative = st.text_input("Enter your Customer narrative:", max_chars=40000, key=None, type="default", placeholder=None, label_visibility="visible")
company = st.text_input("Enter your company name:", max_chars=60, key=None, type="default", placeholder=None, label_visibility="visible")

state = st.text_input("Enter your state in USA:", max_chars=2, key=None, type="default", placeholder=None, label_visibility="visible")
zip_code = st.text_input("Enter your ZIP Code in usa:", max_chars=5, key=None, type="default", placeholder=None, label_visibility="visible")

tags = st.selectbox(
    "Select the Tag with the complaint (if any)",
    ("nan", 'Servicemember', 'Older American, Servicemember',
       'Older American', 'Young Adult Veteran Young Adult',
       '           less', 'Nothing Servicemember Less')
)
customer_consent_provided = st.selectbox(
    "Select if the customer consent is provided: ",
    ("nan", 'Consent not provided', 'Consent provided', 'Other',
       'No response', 'Consent unclear', 'Not specified', 'Unclear',
       'Consent withdrawn')
)

complaint_submission_source = st.selectbox(
    "Select the submission source for the complaint: ",
    ('Referral', 'Web', 'Phone', 'Postal mail', 'Fax', 'Telepathy',
       'Carrier pigeon', 'Smoke signals', 'In-person', 'Email')
)

company_response_to_customer = st.selectbox(
    "Select if the company response sent to customer: ",
    ('Closed with explanation', 'Closed with monetary relief',
       'Closed without relief', 'Closed with non-monetary relief',
       'Closed', 'Closed with relief', 'Response unclear',
       'Resolution provided', 'In progress', 'No resolution provided',
       'Untimely response', 'Company closed')
)

was_response_timely = st.selectbox(
    "Select the response time for the complaint: ",
    ('Yes', 'No', 'Response unclear', 'Not specified', 'Not applicable',
       'Uncertain')
)

consumer_disputed_results = st.selectbox(
    "Did the consumer dispute the results: ",
    ('nan', 'Yes', 'No')
)

transaction_catagory = st.selectbox(
    "What is the transaction catagory: ",
    ('nan', 'Online', 'Retail', 'Bank Transfer', 'PayPal', 'Credit Card', 'Cryptocurrency',
       'BitCoin', 'Barter System')
)

company_public_response = st.selectbox(
    "Select the company public response",
    ("nan",
 'Company believes the complaint is the result of a misunderstanding',
 'Company has responded to the consumer and the CFPB and chooses not to provide a public response',
 'Company chooses not to provide a public response',
 'Company believes it acted appropriately as authorized by contract or law',
 'Company believes complaint caused principally by actions of third party outside the control or direction of the company',
 'Company believes complaint is the result of an isolated error',
 "Company can't verify or dispute the facts in the complaint",
 'Company disputes the facts presented in the complaint',
 'Company believes complaint represents an opportunity for improvement to better serve consumers',
 'Company believes complaint relates to a discontinued policy or procedure')
)

